Project Structure for AITAP Test Automation Project <br>

AITAP-Commons <br>
config		- To keep properties / configuration files for AITAP-Commons <br>
resources	- To keep common resources used in Test Automation project <br>


TestAutomation <br>
config		- To keep application specific properties / configuration files <br>
resources	- To keep resources used in same project <br>
testcases	- To keep test cases created in project <br>
testdata	- To keep test data used in project <br>


Note: Custom keywords under AITAP-Commons will be released and managed by platform team. Do not make any changes in it, if any modification is required contact platform team.  <br>