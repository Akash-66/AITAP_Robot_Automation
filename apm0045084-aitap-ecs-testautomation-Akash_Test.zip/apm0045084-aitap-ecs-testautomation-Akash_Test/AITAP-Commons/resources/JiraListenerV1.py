"""Listener that create defect if a test fails."""

from atlassian import Jira
import logging
from robot.libraries.BuiltIn import BuiltIn
from robot.libraries.OperatingSystem import OperatingSystem
from requests import HTTPError
import yaml
import ast
import os
import glob
import re

JIRA_CONFIG = "jira_config_v1.yaml"
JIRA_TEMPLATE = "jira_issue_template_v1.json"

ROBOT_LISTENER_API_VERSION = 2
log=logging.getLogger("JiraListenerV1")

# Get Current Working Directory
root_dir = os.getcwd()
path=''
# Get Path Of Config File
for relPath,dirs,files in os.walk(root_dir):
	if(JIRA_CONFIG in files):
		path= repr(relPath)[1:-1]

# Read Config File
with open(f'{path}//{JIRA_CONFIG}', 'r') as file:
  jira_constants = yaml.safe_load(file)

def prepare_jira_defect_details(summary,description,tags): 
	_builtin = BuiltIn()
	_os = OperatingSystem()
	file = _os.get_file(f'{path}//{JIRA_TEMPLATE}')
	_builtin.import_variables(f'{path}//{JIRA_CONFIG}')
	_builtin.set_local_variable('$summary',summary)
	_builtin.set_local_variable('$description',description)
	_builtin.set_local_variable('$labels',extract_from_tags('jira_label',tags,jira_constants['labels'])) 
	_builtin.set_local_variable('$severity',extract_from_tags('jira_severity',tags,jira_constants['severity']))
	defect_details = _builtin.replace_variables(file)
	defect_details = ast.literal_eval(defect_details)
	return defect_details
	
def extract_from_tags(tag_key,tags,default_value):
	for tag in tags:
		if ':' in tag:
			val = tag.split(':')
			if tag_key in val[0]:
				return val[1]	
	return default_value
				
def get_latest_file(screenshot_path):
	"""
	Returns path to latest file in a directory from provided path wherer screenshots are saved.
	Inputs screenshot_path - string
	"""
	list_of_files = glob.glob(os.path.join(screenshot_path, '*.png'))
	if len(list_of_files) >0 :
		latest_file = max(list_of_files, key=os.path.getmtime)
		return latest_file 
 
def defect_already_exist(summary, description):
	"""
	This method check weather defect already exist in JIRA or Not.
	Input variables are summary - Test Name and description - Failure Message 
	"""
	jira = Jira(url = jira_constants['jira_url'], token = jira_constants['jira_token']) 
	jql_request = f'project = {jira_constants["jira_project"]} AND  summary ~ \'{summary}\' '
	defect_list = jira.jql(jql_request)
	try:
		if(len(defect_list['issues']) > 0):
			count = defect_list['total']
			if count > 0:
				return defect_list['issues'][0]
		else:
			log.warning('The defect does not exists. Creating new defect.')
			return False
	except ValueError as exception:
			log.warning("Error for finding defect. Details: \n %s.",exception)
			return False
	
def create_new_defect(defect_details):
	"""
	This method create a new defect in JIRA with defect description.
	Input variables are defect_details - Dictionary 
	function will also check if the attachment is available in screenshot directory, if available 
	it will attach the latest one to the defect.
	"""
	jira = Jira(url = jira_constants['jira_url'], token = jira_constants['jira_token']) 
	try:
		new_defect = jira.create_issue(defect_details)
		screenshot_path= root_dir+f"//{jira_constants['screenshot_dir']}"
		file_to_attach = get_latest_file(screenshot_path)
		if file_to_attach is not None:
			jira.add_attachment(new_defect['key'],file_to_attach)
		log.warning("New defect %s is created ",new_defect['key'])
	except HTTPError as exception:
		log.warning("Error creating new defect. Details:%s",exception.response.text)

def add_comment(defect_details,current_defect_desciption):
	"""
	This method add a comment in defect in JIRA.
	Input variables are :
	defect_details - Dictionary 
	current_defect_description - String
	function will also check if the attachment is available in screenshot directory, if available 
	it will attach the latest one to the defect.
	"""
	defect_description_match = re.fullmatch(defect_details['fields']['description'], current_defect_desciption)
	if(defect_description_match is None):
		# adding new failure reason in comment	
		jira = Jira(url=jira_constants['jira_url'], token=jira_constants['jira_token'])
		try:
			jira.issue_add_comment(defect_details['key'],f'Test case failed again with below reason - \n\n "{current_defect_desciption}" ')
			log.warning("Defect comment is updated.")
		except HTTPError as exception:
			log.warning("Error adding new comment in defect. Details:%s",exception.response.text)
	else:
		log.warning("Description provided is already added as a comment.")

def set_defect_status(defect_key):
	"""
	This method update defect status in JIRA with defect key.
	Input variable is defect_key - string 
	"""
	try:
		jira = Jira(url=jira_constants['jira_url'], token=jira_constants['jira_token'])
		respone = jira.set_issue_status(defect_key, jira_constants['retest_failed_status'])
		log.warning('Status for defect %s is updated.', defect_key)
	except HTTPError as exception:
		log.warning("Invalid status provided. Transition from current to provided status is not allowed. \n Exception : %s",exception.response.text)
 
def end_test(test_name, test_attrs):
	# Jira Listener Called when a test case ends and create jira defect in case of test case failed & defect doesn't exists already.
	# Input param Test Case Name and Test Case Attributes
	if test_attrs['status'] == 'FAIL':
		defect_exist = defect_already_exist(test_attrs['longname'], test_attrs['message'])
		jira = Jira(url=jira_constants['jira_url'], token=jira_constants['jira_token'])
		if defect_exist and defect_exist['key']:		
			defect_key = defect_exist['key']
			log.warning("defect with key %s already exists.",defect_key)
			add_comment(defect_exist,test_attrs['message'])
			set_defect_status(defect_key)
		else :
			defect_details = prepare_jira_defect_details(test_attrs['longname'],test_attrs['message'],test_attrs['tags'])
			create_new_defect(defect_details)