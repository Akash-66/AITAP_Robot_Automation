from SeleniumLibrary.keywords import WebDriverCreator
from ExecutionVariables import ExecutionVariables
from ArgumentHandler import ArgumentHandler
from robot.utils.escaping import escape
import os

class BrowserArgumentHandler(ArgumentHandler):

    def __init__(self, managed_keyword):
        super().__init__(managed_keyword)

    def is_chromium(self):
        browser_value = self.value
        mapped_browser_value = WebDriverCreator.browser_names[browser_value]
        return mapped_browser_value in ['edge','chrome','headless_chrome']

class OptionsArgumentHandler(ArgumentHandler):

    DEFAULT_PROXY = 'pxyapp.proxy.att.com:8080'

    def __init__(self, managed_keyword, browser_handler):
        super().__init__(managed_keyword)
        self._enable_proxy = 'False'
        self.browser_handler = browser_handler

    def enable_proxy(self,cmd_line_var):
        self._enable_proxy = ExecutionVariables().get_cmd_line_var_value(cmd_line_var)

    def update_proxy(self, cmd_line_var):
         if(self._enable_proxy and self._enable_proxy.upper() == 'TRUE'):
            proxy = ExecutionVariables().get_cmd_line_var_value(cmd_line_var) or self.DEFAULT_PROXY
            dict_proxy = {'proxyType':'manual'}
            dict_proxy['httpProxy'] = dict_proxy['sslProxy'] = proxy
            set_proxy = 'set_capability("proxy", %s)' % dict_proxy
            self.value += (self.value and ';') + set_proxy

    def set_download_path(self, cmd_line_var):
        download_path = ExecutionVariables().get_cmd_line_var_value(cmd_line_var)
        if not download_path:
            download_path = os.path.join(ExecutionVariables().get_cmd_line_var_value("EXECDIR"), 'testdata', 'downloads')
        if self.browser_handler.is_chromium():
            prefs = {"download.default_directory":escape(download_path)}
            setDownloadDir = f'add_experimental_option("prefs", {prefs})'
        else:
            setDownloadDir = f'set_preference("browser.download.folderList", 2);set_preference("browser.download.dir",r"{escape(download_path)}")'
        self.value += (self.value and ';') + setDownloadDir

    def get_argument_value(self, current_value):
        current_value = current_value or ''
        return current_value + (current_value and self.value and ';') + self.value