from robot.running.arguments import DefaultValue
from ManagedKeywords import ManagedKeywords
from robot.api import logger

class KeywordArgumentReplacer():

    def __init__(self,logger_class, implementation, args, keyword_name):
        self.keyword_name = keyword_name
        self.managed_keyword = ManagedKeywords(keyword_name)
        self.logger_class = logger_class
        self.mapped_arg_list = self.get_mapped_args(implementation,args)
        logger.trace(f"{self.logger_class}: Arguments passed in instruction for Open Browser keyword: {self.mapped_arg_list} ")

    def get_updated_args(self):
        for named_arg in self.managed_keyword.args_to_be_updated:
            self.update_mapped_args(named_arg)
        logger.info(f"{self.logger_class}: Arguments used in execution of Open Browser keyword: {self.mapped_arg_list}")
        return self.mapped_arg_list

    def update_mapped_args(self,named_arg):
        arg_index = self.managed_keyword.get_arg_index(named_arg)
        handler = self.managed_keyword.get_handler(named_arg)
        current_value = self.mapped_arg_list[arg_index]
        arg_value = handler.get_argument_value(current_value)
        if arg_value and arg_value != current_value:
            logger.debug(f"{self.logger_class}: Updating the value of {named_arg} from {current_value} to {arg_value}")
            self.mapped_arg_list[arg_index] = arg_value
        elif (self.managed_keyword.is_arg_mandatory(named_arg) and not current_value):
            logger.warn(f"{self.logger_class}: The value of {list(self.managed_keyword.get_cmd_line_vars(named_arg).keys())} is mandatory for test execution.")

    def get_mapped_args(self,implementation,args):
        postional, named = implementation.resolve_arguments(args)
        mapped_positional,mapped_named = implementation.params.map(postional, named,False)
        mapped_positional = [a.value if isinstance(a, DefaultValue) else a for a in mapped_positional]
        return mapped_positional