from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger
import requests
import json
import re
import dominate
from dominate.tags import *

ROBOT_LISTENER_API_VERSION = 3

class HealingAdapterV1():

    HEALING_URL = 'https://icecap.dev.att.com/api/aiTap/testscript/heal'

    INVALID_LOCATOR_MSG_REGEX = [ ".*with locator.*not found.", "Element.*not visible.*", "Element.*did not appear.*", "Page should have contained (?!text).*but did not.", "Page should have contained text field.*but did not.", "No element with locator.*found."]
    COMBINED_PATTERN = re.compile('|'.join(INVALID_LOCATOR_MSG_REGEX))

    HEALING_TAG = 'healing:continue' #identifies if continue tag is added by healing adapter
    ROBOT_CONTINUE_TAG = 'robot:continue-on-failure' #tag to continue test execution in case of failure
    ROBOT_SKIP_TAG = 'robot:skip-on-failure' #tag to skip test execution in case of failure

    TAGS_TO_REMOVE = ["style", "script", "path"]
    ATTRIBUTES_TO_REMOVE = ["style", "path", "viewBox"]
    TAGS_REGEX = [r'<{}\b[^>]*>.*?</{}>'.format(tag, tag) for tag in TAGS_TO_REMOVE]
    ATTR_REGEX = [r'\s([{}=]+)=.*?(\'[^\']*\'|\"[^\"]*\")'.format(attr) for attr in ATTRIBUTES_TO_REMOVE]
    TAGS_PATTERN = re.compile('|'.join(TAGS_REGEX), re.DOTALL)
    ATTRS_PATTERN = re.compile('|'.join(ATTR_REGEX))

    LOCATOR_HEAL_SUCCESS_STATUS_CODE = 200
    APP_NOT_ONBOARDED_STATUS_CODE = 403    
    HEALED_SUCCESSFULLY = 'Healed Successfully'

    ALLOW_HEALING_FOR_KEYWORDS = ['Run Keyword', 'Run Keyword If', 'Run Keyword If All Tests Passed', 'Run Keyword If Test Passed']

    HEALING_RESULT_TABLE_HEADERS = ['Failed Locator', 'Healed Locator']

    def __init__(self):
        self.is_app_onboarded = True
        self.healed_locators = {}   # Map to store healed locators

    def start_suite(self, data, result):
        self.builtin_lib = BuiltIn()
        self.selenium_lib = self.builtin_lib.get_library_instance('SeleniumLibrary')

    def start_keyword(self, data, result):
        # Remove ROBOT_CONTINUE_TAG tag in case it was added by the healing adapter, to stop test execution if another failure occurs
        # Use HEALING_TAG to determine if tag was added by healing adapter   
        if(hasattr(data.parent, "tags") and self.HEALING_TAG in data.parent.tags):            
            self.update_tags(data,result,'remove')

    def end_library_keyword(self, data, impl, result):
        # Check for various error patterns           
        if(result.status == 'FAIL'):
            if(self.is_healing_allowed(impl, result)): self.heal_failed_step(data, result)
            if(impl.owner.name == 'BuiltIn' and impl.name in self.ALLOW_HEALING_FOR_KEYWORDS):
                self.update_status_and_continue_execution(data, result)

    def end_user_keyword(self, data, impl, result):
        if(result.status == 'FAIL'):
            self.update_status_and_continue_execution(data, result)

    def end_test(self, data, result):        
        if(result.status == 'FAIL' or (result.status == 'SKIP' and self.ROBOT_SKIP_TAG in data.tags)):
            self.update_status_if_healed(result)

    def report_file(self, path):
        if(self.healed_locators):
            self.append_healing_details_table_to_report_html(path)
    
    def is_healing_allowed(self, impl, result): 
        is_selenium_library_error = impl.owner.name == 'SeleniumLibrary' and self.COMBINED_PATTERN.match(result.message) \
                and impl.params.argument_names[0] == 'locator' 
        is_runkeyword_and_healing_allowed = ((not hasattr(result.parent, 'owner') or not result.parent.owner) or
        (result.parent.owner == 'BuiltIn' and result.parent.name in self.ALLOW_HEALING_FOR_KEYWORDS))
        return  is_selenium_library_error and self.is_app_onboarded and is_runkeyword_and_healing_allowed
                
    def heal_failed_step(self, data, result):              
        locator = data.args[0]
        if(locator not in self.healed_locators):
            # Send call to genai and get healed locator.   
            healed_locator = self.get_healed_locator(data, result)  
        else:             
            healed_locator = self.healed_locators[locator] 
            logger.info(f"Healed locator found in GenAI responses cache, executing failed instruction with locator : {healed_locator}")
        if(healed_locator):                
            self.healed_locators[locator] = healed_locator
            self.highlight_and_take_screenshot(healed_locator)
            self.rerun_step_and_continue_execution(data, result, healed_locator)

    def rerun_step_and_continue_execution(self, data, result, healed_locator):
        data.args = (healed_locator, *data.args[1:])
        is_run_success = self.builtin_lib.run_keyword_and_return_status(data.name, *data.args)
        if(is_run_success):            
            result.status ='PASS'
            result.message = self.HEALED_SUCCESSFULLY
            #Add 'robot:continue-on-failure' tag to continue keyword execution in case of successful Healing.
            self.update_tags(data, result, 'add')

    def highlight_and_take_screenshot(self, healed_locator):
        web_element = self.selenium_lib.get_webelement(healed_locator)
        current_log_level = self.builtin_lib.set_log_level('NONE')
        self.selenium_lib.execute_javascript("arguments[0].style.border='2px solid red'", 'ARGUMENTS' , web_element)
        self.builtin_lib.set_log_level(current_log_level)
        self.selenium_lib.capture_page_screenshot()

    def update_tags(self, data, result, operation):
        if(not hasattr(data.parent, "tags")): return
        if(self.ROBOT_CONTINUE_TAG not in data.parent.tags):
            getattr(data.parent.tags, operation)(self.HEALING_TAG)
        # current defect in RF, adding tag in 'result' works for test case and in 'data' works for user keyword
        # Open Defect : https://github.com/robotframework/robotframework/issues/5112
        getattr(result.parent.tags, operation)(self.ROBOT_CONTINUE_TAG)
        getattr(data.parent.tags, operation)(self.ROBOT_CONTINUE_TAG)

    def remove_unnecessary_tags(self, dom):
        """Removes the html tags and attributes that are added in the global pattern"""
        dom = re.sub(self.TAGS_PATTERN, '', dom)
        dom = re.sub(self.ATTRS_PATTERN, '', dom)
        return dom

    def create_payload(self, data, result):
        request_payload = {}
        request_payload['pageURL'] = self.selenium_lib.get_location()
        runtimeDOM = self.selenium_lib.get_source()
        runtimeDOM = self.remove_unnecessary_tags(runtimeDOM)        
        request_payload['runtimeDOM'] = runtimeDOM
        request_payload['failedInstruction'] = str(data)
        request_payload['errorMessage'] = result.message
        request_payload['brokenLocator'] = result.args[0]
        return json.dumps(request_payload)

    def get_healed_locator(self, data, result):    
        request_payload = self.create_payload(data, result)   
        headers = {"Content-Type": "application/json; charset=utf-8"}
        healing_response = requests.post(self.HEALING_URL, headers=headers, data = request_payload)
        logger.debug(f"Healing API Response code: {healing_response.status_code} ")
        healing_response_json = healing_response.json()            
        if(healing_response.status_code == self.LOCATOR_HEAL_SUCCESS_STATUS_CODE) :        
            healed_locator = healing_response_json['healedLocator']
            logger.info(f"New locator received from GenAI, executing failed instruction with locator : {healed_locator}")
            return healed_locator
        else:
            logger.warn(healing_response_json['error']['message'])                  
            if(healing_response.status_code == self.APP_NOT_ONBOARDED_STATUS_CODE) :                                 
                self.is_app_onboarded = False     
                        
    def update_status_if_healed(self, result):
        for kw in result.body:
            if(kw.message and kw.message != self.HEALED_SUCCESSFULLY):
                return False
        result.status = 'PASS'
        result.message = self.HEALED_SUCCESSFULLY
        return True
    
    def update_status_and_continue_execution(self, data, result):
        if(self.update_status_if_healed(result)): 
            #Add 'robot:continue-on-failure' tag to continue test execution in case of successful Healing.
            self.update_tags(data, result, 'add')
    
    def append_healing_details_table_to_report_html(self, path):
            file = open(path, 'r+', encoding="utf-8")
            report_content = file.read()
            report_document = dominate.document(report_content)
            with report_document:
                with h2():
                    h2('AITAP Healing Details')
                with table(cls='statistics tablesorter tablesorter-default tablesorter*'):
                    with thead().add(tr(cls='tablesorter-headerRow')): 
                        for header_name in self.HEALING_RESULT_TABLE_HEADERS:
                            th(header_name, cls='tablesorter-header-inner')
                    with tbody():
                        for failed_locator, healed_locator in self.healed_locators.items():
                            with tr():
                                td(failed_locator, cls='stats-col-name')
                                td(healed_locator, cls='stats-col-name')
            file.write(report_document.render())
            file.close()