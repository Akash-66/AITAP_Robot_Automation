###
# The AITAP-Adapter is an adapter designed for handling the "Open Browser" keyword in  
# Test Suite Setup / same Resource /  Test Case Setup / Test Case Body.
# This adapter specifically uses the power of Listener Version 3. As it allows to modify the 
# data while execution.
###

from ManagedKeywords import ManagedKeywords
from KeywordArgumentReplacer import KeywordArgumentReplacer

ROBOT_LISTENER_API_VERSION = 3

class AitapAdapterV1():

    def start_library_keyword(self, data, implementation, result):
        for handled_keyword in ManagedKeywords.KEYWORDS_TO_BE_HANDLED:
            if (implementation.matches(handled_keyword)):
                handler = KeywordArgumentReplacer(self.__class__.__name__, implementation, data.args, handled_keyword)
                data.args = handler.get_updated_args()