from robot.libraries.BuiltIn import BuiltIn

class ExecutionVariables():

    RESOURCE_VARIABLES = None

    def get_cmd_line_var_value(self, cmd_line_var):
        if not ExecutionVariables.RESOURCE_VARIABLES: ExecutionVariables.RESOURCE_VARIABLES =  BuiltIn().get_variables() # It will return a dict
        return ExecutionVariables.RESOURCE_VARIABLES.get('${%s}' % cmd_line_var)