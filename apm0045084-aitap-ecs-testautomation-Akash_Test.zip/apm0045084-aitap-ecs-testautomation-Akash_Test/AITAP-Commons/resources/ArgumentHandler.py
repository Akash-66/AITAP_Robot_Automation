from ExecutionVariables import ExecutionVariables

class ArgumentHandler():

    def __init__(self, managed_keyword):
        self.managed_keyword = managed_keyword
        self.value = ''

    def set_argument_value(self, cmd_line_var):
        self.value = ExecutionVariables().get_cmd_line_var_value(cmd_line_var)

    def get_argument_value(self, current_value):
        self.value = self.value or current_value
        return self.value