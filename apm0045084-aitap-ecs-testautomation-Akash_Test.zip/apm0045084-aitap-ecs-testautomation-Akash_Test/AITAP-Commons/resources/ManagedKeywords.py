from ArgumentHandler import ArgumentHandler
from OpenBrowserKeywordHandler import OptionsArgumentHandler, BrowserArgumentHandler

class ManagedKeywords():
    """ named_arg --> Name of the argument that needs to be updated by handler
        arg_index --> The default position of the argument in keyword argument specification
        cmd_line_vars --> The Dict of the cmd line variable and the method that is supposed to be called in handler
        arg_mandatory --> If True then argument should be passed either in testcase or from command line for test execution
        handler --> The handler class that will be used to update the argument value """

    KEYWORDS_TO_BE_HANDLED = {
            "Open Browser": {
                'browser': { 'arg_index': 1, 'cmd_line_vars': {'V_BROWSER':'set_argument_value'}, 'arg_mandatory': False, 'handler': BrowserArgumentHandler },
                'remote_url': { 'arg_index': 3, 'cmd_line_vars': {'V_REMOTE_URL':'set_argument_value'}, 'arg_mandatory': True, 'handler': ArgumentHandler },
                'options': { 'arg_index': 6, 'cmd_line_vars': {'V_ENABLE_PROXY': 'enable_proxy', 'V_PROXY':'update_proxy', 'V_DOWNLOADS_PATH':'set_download_path'}, 'arg_mandatory': False, 'handler': lambda mk: OptionsArgumentHandler(mk, mk.get_handler_instance('browser'))}
            }
        }

    def __init__(self, keyword_name):
        self.args_to_be_updated = self.KEYWORDS_TO_BE_HANDLED[keyword_name]
        self.argument_handlers = {}

    def get_arg_index(self, named_arg):
        return self.args_to_be_updated[named_arg]['arg_index']

    def get_cmd_line_vars(self, named_arg):
        return self.args_to_be_updated[named_arg]['cmd_line_vars']

    def is_arg_mandatory(self, named_arg):
        return self.args_to_be_updated[named_arg]['arg_mandatory']

    def get_arg_to_cmd_var_map(self):
        return {named_arg:self.get_cmd_line_vars(named_arg) for named_arg in self.args_to_be_updated}
    
    def get_handler(self, named_arg):
        handler = self.args_to_be_updated[named_arg]['handler'](self)
        self.argument_handlers[named_arg] = handler
        for cmd_line_var, method_name in self.get_cmd_line_vars(named_arg).items():
            getattr(handler, method_name)(cmd_line_var)
        return handler
    
    def get_handler_instance(self, named_arg):
        return self.argument_handlers[named_arg]